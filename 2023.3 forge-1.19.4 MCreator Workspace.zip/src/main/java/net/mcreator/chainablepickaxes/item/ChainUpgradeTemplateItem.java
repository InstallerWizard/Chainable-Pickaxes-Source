
package net.mcreator.chainablepickaxes.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class ChainUpgradeTemplateItem extends Item {
	public ChainUpgradeTemplateItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.UNCOMMON));
	}
}
