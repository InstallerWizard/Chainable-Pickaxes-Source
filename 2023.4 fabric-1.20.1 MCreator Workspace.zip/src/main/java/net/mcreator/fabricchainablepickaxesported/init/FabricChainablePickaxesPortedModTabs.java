
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.fabricchainablepickaxesported.init;

import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.Registry;

import net.mcreator.fabricchainablepickaxesported.FabricChainablePickaxesPortedMod;

import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;

public class FabricChainablePickaxesPortedModTabs {
	public static ResourceKey<CreativeModeTab> TAB_CHAINABLEPICKAXES = ResourceKey.create(Registries.CREATIVE_MODE_TAB, new ResourceLocation(FabricChainablePickaxesPortedMod.MODID, "chainablepickaxes"));

	public static void load() {
		Registry.register(BuiltInRegistries.CREATIVE_MODE_TAB, TAB_CHAINABLEPICKAXES,
				FabricItemGroup.builder().title(Component.translatable("item_group." + FabricChainablePickaxesPortedMod.MODID + ".chainablepickaxes")).icon(() -> new ItemStack(Items.NETHERITE_PICKAXE)).build());
	}
}
