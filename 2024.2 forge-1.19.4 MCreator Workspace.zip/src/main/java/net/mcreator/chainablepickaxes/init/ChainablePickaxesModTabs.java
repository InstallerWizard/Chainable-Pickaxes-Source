
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.chainablepickaxes.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.CreativeModeTabEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class ChainablePickaxesModTabs {
	@SubscribeEvent
	public static void buildTabContentsModded(CreativeModeTabEvent.Register event) {
		event.registerCreativeModeTab(new ResourceLocation("chainable_pickaxes", "chainable_pickaxes"),
				builder -> builder.title(Component.translatable("item_group.chainable_pickaxes.chainable_pickaxes")).icon(() -> new ItemStack(ChainablePickaxesModItems.CHAIN_UPGRADE_TEMPLATE.get())).displayItems((parameters, tabData) -> {
					tabData.accept(ChainablePickaxesModItems.CHAINED_NETHERITE_PICKAXE.get());
					tabData.accept(ChainablePickaxesModItems.CHAINED_DIAMOND_PICKAXE.get());
					tabData.accept(ChainablePickaxesModItems.CHAINED_IRON_PICKAXE.get());
					tabData.accept(ChainablePickaxesModItems.CHAINED_GOLDEN_PICKAXE.get());
					tabData.accept(ChainablePickaxesModItems.CHAINED_WOODEN_PICKAXE.get());
					tabData.accept(ChainablePickaxesModItems.CHAIN_UPGRADE_TEMPLATE.get());
				})

		);
	}

	@SubscribeEvent
	public static void buildTabContentsVanilla(CreativeModeTabEvent.BuildContents tabData) {
		if (tabData.getTab() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(ChainablePickaxesModItems.CHAINED_STONE_PICKAXE.get());
		}
	}
}
