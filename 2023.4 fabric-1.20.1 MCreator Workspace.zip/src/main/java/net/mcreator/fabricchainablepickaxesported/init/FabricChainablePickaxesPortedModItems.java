/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.fabricchainablepickaxesported.init;

import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.Registry;
import net.minecraft.client.renderer.item.ItemProperties;
import net.minecraft.client.renderer.item.ClampedItemPropertyFunction;

import net.mcreator.fabricchainablepickaxesported.item.ChaineddiamondpickaxeItem;
import net.mcreator.fabricchainablepickaxesported.item.ChainedWoodenPickaxeItem;
import net.mcreator.fabricchainablepickaxesported.item.ChainedStonePickaxeItem;
import net.mcreator.fabricchainablepickaxesported.item.ChainedNetheritePickaxeItem;
import net.mcreator.fabricchainablepickaxesported.item.ChainedIronPickaxeItem;
import net.mcreator.fabricchainablepickaxesported.item.ChainedGoldPickaxeItem;
import net.mcreator.fabricchainablepickaxesported.item.ChainUpgradetemplateItem;
import net.mcreator.fabricchainablepickaxesported.FabricChainablePickaxesPortedMod;

public class FabricChainablePickaxesPortedModItems {
	public static Item CHAINED_WOODEN_PICKAXE;
	public static Item CHAINED_STONE_PICKAXE;
	public static Item CHAINED_GOLD_PICKAXE;
	public static Item CHAINED_IRON_PICKAXE;
	public static Item CHAINEDDIAMONDPICKAXE;
	public static Item CHAINED_NETHERITE_PICKAXE;
	public static Item CHAIN_UPGRADETEMPLATE;

	public static void load() {
		CHAINED_WOODEN_PICKAXE = register("chained_wooden_pickaxe", new ChainedWoodenPickaxeItem());
		CHAINED_STONE_PICKAXE = register("chained_stone_pickaxe", new ChainedStonePickaxeItem());
		CHAINED_GOLD_PICKAXE = register("chained_gold_pickaxe", new ChainedGoldPickaxeItem());
		CHAINED_IRON_PICKAXE = register("chained_iron_pickaxe", new ChainedIronPickaxeItem());
		CHAINEDDIAMONDPICKAXE = register("chaineddiamondpickaxe", new ChaineddiamondpickaxeItem());
		CHAINED_NETHERITE_PICKAXE = register("chained_netherite_pickaxe", new ChainedNetheritePickaxeItem());
		CHAIN_UPGRADETEMPLATE = register("chain_upgradetemplate", new ChainUpgradetemplateItem());
	}

	public static void clientLoad() {
	}

	private static Item register(String registryName, Item item) {
		return Registry.register(BuiltInRegistries.ITEM, new ResourceLocation(FabricChainablePickaxesPortedMod.MODID, registryName), item);
	}

	private static void registerBlockingProperty(Item item) {
		ItemProperties.register(item, new ResourceLocation("blocking"), (ClampedItemPropertyFunction) ItemProperties.getProperty(Items.SHIELD, new ResourceLocation("blocking")));
	}
}
