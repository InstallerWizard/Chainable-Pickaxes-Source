
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.chainablepickaxes.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.Item;

import net.mcreator.chainablepickaxes.item.ChainedWoodenPickaxeItem;
import net.mcreator.chainablepickaxes.item.ChainedStonePickaxeItem;
import net.mcreator.chainablepickaxes.item.ChainedNetheritePickaxeItem;
import net.mcreator.chainablepickaxes.item.ChainedIronPickaxeItem;
import net.mcreator.chainablepickaxes.item.ChainedGoldenPickaxeItem;
import net.mcreator.chainablepickaxes.item.ChainedDiamondPickaxeItem;
import net.mcreator.chainablepickaxes.item.ChainUpgradeTemplateItem;
import net.mcreator.chainablepickaxes.ChainablePickaxesMod;

public class ChainablePickaxesModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, ChainablePickaxesMod.MODID);
	public static final RegistryObject<Item> CHAINED_NETHERITE_PICKAXE = REGISTRY.register("chained_netherite_pickaxe", () -> new ChainedNetheritePickaxeItem());
	public static final RegistryObject<Item> CHAINED_DIAMOND_PICKAXE = REGISTRY.register("chained_diamond_pickaxe", () -> new ChainedDiamondPickaxeItem());
	public static final RegistryObject<Item> CHAINED_IRON_PICKAXE = REGISTRY.register("chained_iron_pickaxe", () -> new ChainedIronPickaxeItem());
	public static final RegistryObject<Item> CHAINED_STONE_PICKAXE = REGISTRY.register("chained_stone_pickaxe", () -> new ChainedStonePickaxeItem());
	public static final RegistryObject<Item> CHAINED_GOLDEN_PICKAXE = REGISTRY.register("chained_golden_pickaxe", () -> new ChainedGoldenPickaxeItem());
	public static final RegistryObject<Item> CHAINED_WOODEN_PICKAXE = REGISTRY.register("chained_wooden_pickaxe", () -> new ChainedWoodenPickaxeItem());
	public static final RegistryObject<Item> CHAIN_UPGRADE_TEMPLATE = REGISTRY.register("chain_upgrade_template", () -> new ChainUpgradeTemplateItem());
	// Start of user code block custom items
	// End of user code block custom items
}
